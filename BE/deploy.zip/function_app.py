import azure.functions as func
import requests

app = func.FunctionApp()

@app.route(route="run_databricks_job", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def run_databricks_job(req: func.HttpRequest):
    try:
        # Перевірка, що requests працює
        response = requests.get("https://httpbin.org/get")
        return func.HttpResponse(
            f"requests library works! Status code: {response.status_code}",
            status_code=200
        )
    except Exception as e:
        return func.HttpResponse(
            f"Error: {str(e)}",
            status_code=500
        )
