import azure.functions as func
#import requests

app = func.FunctionApp()

@app.route(route="run_databricks_job", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def run_databricks_job(req: func.HttpRequest):
    return func.HttpResponse(
        "requests import OK",
        status_code=200
    )
